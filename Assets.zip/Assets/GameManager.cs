using UnityEngine;

public class GameManager : MonoBehaviour
{
    [Header("Event Triggers")]
    public int scoreToTriggerEvent = 100; // When to start the dialogue

    [Header("Game Object References")]
    public DebrisSpawner debrisSpawner;
    public BarrelSpawner barrelSpawner;
    public DialogueManager dialogueManager;

    [Header("Event Dialogue")]
    public Dialogue heroVsVillainDialogue;

    private int playerScore = 0;
    private bool hasTriggeredDialogue = false;

    void Start()
    {
        // Start dialogue after Unity finishes all initialization
        StartCoroutine(StartDialogueAfterDelay());
    }

    private System.Collections.IEnumerator StartDialogueAfterDelay()
    {
        yield return null; // wait 1 frame for all objects (like DialogueManager UI refs) to initialize

        if (dialogueManager != null && heroVsVillainDialogue != null)
        {
            Debug.Log("✅ GameManager: Starting dialogue safely after initialization...");
            dialogueManager.StartDialogue(heroVsVillainDialogue);
        }
        else
        {
            Debug.LogError("❌ GameManager: DialogueManager or Dialogue reference missing!");
        }
    }

    void Update()
    {
        // In your real game, playerScore should be updated elsewhere.
        // For testing, you can simulate score increase:
        // playerScore += 1;  // Uncomment to auto-increase score in play mode

        // Trigger dialogue once when score reaches threshold
        if (!hasTriggeredDialogue && playerScore >= scoreToTriggerEvent)
        {
            Debug.Log("Score threshold reached! Starting dialogue...");
            dialogueManager.StartDialogue(heroVsVillainDialogue);
            hasTriggeredDialogue = true;
        }
    }

    // Optional method to let other scripts increase score safely
    public void AddScore(int amount)
    {
        playerScore += amount;
        Debug.Log("Player Score: " + playerScore);
    }
}