using UnityEngine;

public class FreezeManager : MonoBehaviour
{
    public bool IsFrozen { get; private set; } = false;
    public float defaultFreezeDuration = 5f; // optional

    public void Freeze()
    {
        if (IsFrozen) return;
        IsFrozen = true;
        Time.timeScale = 0f;
        Debug.Log("FreezeManager: Time frozen");
    }

    public void Unfreeze()
    {
        if (!IsFrozen) return;
        IsFrozen = false;
        Time.timeScale = 1f;
        Debug.Log("FreezeManager: Time resumed");
    }
}