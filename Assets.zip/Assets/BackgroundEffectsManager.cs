using UnityEngine;

public class BackgroundEffectsManager : MonoBehaviour
{
    public GameObject[] effects;  // Fireball, laser, smoke puff, etc.
    public float minSpawnTime = 0.4f;
    public float maxSpawnTime = 1.2f;
    public Transform leftSpawnPoint;
    public Transform rightSpawnPoint;

    private bool spawning = false;

    void Start()
    {
        StartSpawning();
    }

    public void StartSpawning()
    {
        if (!spawning)
        {
            spawning = true;
            StartCoroutine(SpawnRoutine());
        }
    }

    public void StopSpawning()
    {
        spawning = false;
        StopAllCoroutines();
    }

    private System.Collections.IEnumerator SpawnRoutine()
    {
        while (spawning)
        {
            yield return new WaitForSeconds(Random.Range(minSpawnTime, maxSpawnTime));
            SpawnRandomEffect();
        }
    }

    void SpawnRandomEffect()
    {
        GameObject prefab = effects[Random.Range(0, effects.Length)];

        // Randomly choose left or right spawn
        Transform spawnPoint = (Random.value < 0.5f) ? leftSpawnPoint : rightSpawnPoint;

        Instantiate(prefab, spawnPoint.position, Quaternion.identity);
    }
}